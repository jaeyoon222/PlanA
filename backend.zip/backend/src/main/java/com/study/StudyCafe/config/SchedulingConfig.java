package com.study.StudyCafe.config;// 아무 @Configuration 에나
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@Configuration
public class SchedulingConfig {}
