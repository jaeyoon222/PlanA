//package com.study.StudyCafe.dto.user;
//
//import lombok.Getter;
//import lombok.Setter;
//
//import java.time.LocalDate;
//
//@Getter
//@Setter
//public class UserProfileDto {
//    private Long userId;
//    private String name;
//    private String nickname;
//    private String email;
//    private String phone;
//    private String address;
//    private String profileImage;
//    private String provider;
//    private String role;
//    private LocalDate birthDate;
//}
