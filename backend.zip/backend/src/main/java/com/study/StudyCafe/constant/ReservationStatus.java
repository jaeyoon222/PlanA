package com.study.StudyCafe.constant;

public enum ReservationStatus {
    RESERVED, CANCELED
}
