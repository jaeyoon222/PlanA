package com.study.StudyCafe.dto.NLP;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class BranchDto {
    private String name;
    private Long zoneId;
}