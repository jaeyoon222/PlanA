package com.study.StudyCafe.constant;

public enum OrderStatus {
    PAID, CANCEL, REFUND
}
