package com.study.StudyCafe.constant;

public enum UserRole {
    ADMIN, USER
}
