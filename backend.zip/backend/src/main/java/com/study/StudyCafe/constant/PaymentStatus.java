package com.study.StudyCafe.constant;

public enum PaymentStatus {
    PAID, CANCEL, FAIL
}
